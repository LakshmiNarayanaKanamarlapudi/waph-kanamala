create database if not exists  project2;
create user 'lakshman'@'localhost'IDENTIFIED BY 'Pa$$w0rd';
GRANT ALL ON project2.* TO 'lakshman'@'localhost';

