DROP TABLE IF EXISTS users;
CREATE TABLE users(
  username VARCHAR(50) PRIMARY KEY,
  password VARCHAR(100) NOT NULL,
  additional_email VARCHAR(100),
  phone VARCHAR(20)
  name VARCHAR(20),
  emai VARCHAR(50)
);


