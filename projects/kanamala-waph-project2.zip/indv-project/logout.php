<?php
    
    session_start();
    session_destroy();
?>
<link rel="stylesheet" type="text/css" href="style.css">

<p> You are logout! </p>
<p><a href="form.php">Login again</a></p>
